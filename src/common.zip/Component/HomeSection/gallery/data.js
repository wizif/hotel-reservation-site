const data = [
  {
    cover: "./images/gallery-1.png",
  },
  {
    cover: "./images/gallery-1.png",
  },
  {
    cover: "./images/hotel1.png",
  },
  {
    cover: "./images/gallery-1.png",
  },
  {
    cover: "./images/gallery-1.png",
  },
  {
    cover: "./images/gallery-1.png",
  },
  {
    cover: "./images/gallery-1.png",
  },
]

export default data